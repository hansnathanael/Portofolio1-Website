$(document).ready(function(){
    let totalSlide = $('.sliding').length;
    let slideWidth = $('.sliding').width();
    let slideHeight = $('.sliding').height();
    let totalWidth = totalSlide*slideWidth;

    $('.slider').css({width: slideWidth, height: slideHeight})
    $('.slider .slides').css({width: totalWidth, marginLeft: -slideWidth});
    $('.slider .slides .sliding:last-child').prependTo('.slider .slides');

    $('#prev').click(function(){
        $('.slider .slides').animate({
            left : slideWidth
        }, 800, function(){
            $('.slider .slides .sliding:last-child').prependTo('.slider .slides');
            $('.slider .slides').css({left : ''})
        })
    })

    $('#next').click(function(){
        $('.slider .slides').animate({
            left : -slideWidth
        }, 800, function(){
            $('.slider .slides .sliding:first-child').appendTo('.slider .slides');
            $('.slider .slides').css({left : ''})
        })
    })
})