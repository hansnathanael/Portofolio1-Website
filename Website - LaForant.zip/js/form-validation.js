function validation(){
    let username = document.getElementById('username')
    let email = document.getElementById('email')
    let dob = document.getElementById('dob')
    let nationality = document.getElementById('nationality')
    let password = document.getElementById('password')
    let agreement = document.getElementById('agreement')
    let errorMsg = []

    usernameValidation(username, errorMsg)
    emailValidation(email, errorMsg)
    dobValidation(dob, errorMsg)
    nationalityValidation(nationality, errorMsg)
    passwordValidation(password, errorMsg)
    agreementValidation(agreement, errorMsg)
    fun(errorMsg)

    if (errorMsg.length === 0){
        alert('Registration Success!');
    } else{
        alert(errorMsg.join('\n'))
    }
}

let usernameValidation = (username, errorMsg) => {
    if (username.value === ''){
        errorMsg.push('Username Must Be Filled!')
    } else if (username.value.length < 6){
        errorMsg.push('Username Length Min. 6')
    }
}

let emailValidation = (email, errorMsg) => {
    if (email.value === ''){
        errorMsg.push('Email Must Be Filled!')
    } else if (email.value.startsWith('.') || email.value.startsWith('@')){
        errorMsg.push('Email Cannot Starts with . or @')
    } else if (email.value.indexOf('.') === (email.value.indexOf('@') + 1)){
        errorMsg.push('Email Cannot Contain . after @')
    }
}

let dobValidation = (dob, errorMsg) => {
    if (dob.value === ''){
        errorMsg.push('Date of Birth Must Be Filled!')
    }
}

let nationalityValidation = (nationality, errorMsg) => {
    if (nationality.value === ''){
        errorMsg.push('Nationality Must Be Filled!')
    } else if (nationality.value.length < 4){
        errorMsg.push('Nationality Length Min. 4')
    }
}

let passwordValidation = (password, errorMsg) => {
    if (password.value === ''){
        errorMsg.push('Password Must Be Filled!')
    } else if (password.value.length < 8){
        errorMsg.push('Password Length Min. 8')
    }
}

let agreementValidation = (agreement, errorMsg) => {
    if (!agreement.checked){
        errorMsg.push('Need To Accept Terms of Service To Continue!')
    }
}

function fun(errorMsg){
    if (errorMsg.length === 0){
        username.value = ''
        email.value = ''
        nationality.value = ''
        password.value = ''
        agreement.checked = false
        dob.value = ''  
    }
}